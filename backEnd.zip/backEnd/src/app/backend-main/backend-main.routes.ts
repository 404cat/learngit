import { RouterModule } from '@angular/router';
import { BackendMainComponent } from './backend-main.component';

export const backendMainroutes = [
    {
        path: '',
        component: BackendMainComponent
    }
];
